// APSOLDE - Client-side JavaScript for enhanced user experience

document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('balanceForm');
    const submitBtn = document.getElementById('submitBtn');
    const loadingSpinner = document.getElementById('loadingSpinner');
    const btnText = document.querySelector('.btn-text');
    const nomInput = document.getElementById('nom');
    const compteInput = document.getElementById('compte');

    // Account number format validation
    const accountPattern = /^[A-Za-z]{1}\d{6}-\d{2}$/;

    // Real-time validation for account number
    compteInput.addEventListener('input', function() {
        const value = this.value.trim();
        
        if (value && !accountPattern.test(value)) {
            this.classList.add('is-invalid');
            this.classList.remove('is-valid');
        } else if (value) {
            this.classList.add('is-valid');
            this.classList.remove('is-invalid');
        } else {
            this.classList.remove('is-valid', 'is-invalid');
        }
    });

    // Format account number input (auto-add dash)
    compteInput.addEventListener('input', function() {
        let value = this.value.replace(/[^A-Za-z0-9]/g, '');
        
        if (value.length > 7) {
            value = value.substring(0, 7) + '-' + value.substring(7, 9);
        }
        
        this.value = value.toUpperCase();
    });

    // Form submission with loading state
    form.addEventListener('submit', function(e) {
        // Hide previous results
        hideResult();
        
        // Show loading state
        showLoadingState();
        
        // Validate inputs before submission
        const nom = nomInput.value.trim();
        const compte = compteInput.value.trim();
        
        if (!nom || !compte) {
            e.preventDefault();
            hideLoadingState();
            showValidationError('Veuillez remplir tous les champs');
            return;
        }
        
        if (!accountPattern.test(compte)) {
            e.preventDefault();
            hideLoadingState();
            showValidationError('Format du numéro de compte invalide');
            return;
        }
    });

    // Auto-dismiss only error and warning alerts after 5 seconds, keep success alerts visible
    setTimeout(function() {
        const alerts = document.querySelectorAll('.alert-danger, .alert-warning');
        alerts.forEach(function(alert) {
            const bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        });
    }, 5000);

    // Helper functions
    function showLoadingState() {
        submitBtn.disabled = true;
        submitBtn.classList.add('btn-loading');
        loadingSpinner.classList.remove('d-none');
        btnText.textContent = 'Vérification en cours...';
    }

    function hideLoadingState() {
        submitBtn.disabled = false;
        submitBtn.classList.remove('btn-loading');
        loadingSpinner.classList.add('d-none');
        btnText.textContent = 'Vérifier le Solde';
    }

    function showValidationError(message) {
        // Create and show validation error alert
        const alertDiv = document.createElement('div');
        alertDiv.className = 'alert alert-danger alert-dismissible fade show';
        alertDiv.innerHTML = `
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;
        
        // Insert before the form
        form.parentNode.insertBefore(alertDiv, form);
        
        // Auto-dismiss validation errors after 3 seconds
        setTimeout(function() {
            const bsAlert = new bootstrap.Alert(alertDiv);
            bsAlert.close();
        }, 3000);
    }

    // Enhanced form validation feedback
    function validateForm() {
        const nom = nomInput.value.trim();
        const compte = compteInput.value.trim();
        let isValid = true;

        // Reset validation states
        nomInput.classList.remove('is-valid', 'is-invalid');
        compteInput.classList.remove('is-valid', 'is-invalid');

        // Validate name
        if (!nom) {
            nomInput.classList.add('is-invalid');
            isValid = false;
        } else {
            nomInput.classList.add('is-valid');
        }

        // Validate account number
        if (!compte || !accountPattern.test(compte)) {
            compteInput.classList.add('is-invalid');
            isValid = false;
        } else {
            compteInput.classList.add('is-valid');
        }

        return isValid;
    }

    // Input focus effects
    const inputs = [nomInput, compteInput];
    inputs.forEach(input => {
        input.addEventListener('focus', function() {
            this.parentElement.classList.add('input-focused');
        });
        
        input.addEventListener('blur', function() {
            this.parentElement.classList.remove('input-focused');
        });
    });

    // Keyboard shortcuts
    document.addEventListener('keydown', function(e) {
        // Enter key to submit (when form is valid)
        if (e.key === 'Enter' && e.target.tagName !== 'BUTTON') {
            if (validateForm()) {
                form.submit();
            }
        }
        
        // Escape key to clear form
        if (e.key === 'Escape') {
            nomInput.value = '';
            compteInput.value = '';
            nomInput.classList.remove('is-valid', 'is-invalid');
            compteInput.classList.remove('is-valid', 'is-invalid');
            nomInput.focus();
        }
    });

    // Smooth scroll to alerts
    const alerts = document.querySelectorAll('.alert');
    if (alerts.length > 0) {
        alerts[0].scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
});

// Function to show result in dedicated section
function showResult(message) {
    const resultSection = document.getElementById('resultSection');
    const resultContent = document.getElementById('resultContent');
    
    if (resultSection && resultContent) {
        resultContent.innerHTML = message;
        resultSection.style.display = 'block';
        
        // Scroll to result
        resultSection.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
}

// Function to hide result section
function hideResult() {
    const resultSection = document.getElementById('resultSection');
    if (resultSection) {
        resultSection.style.display = 'none';
    }
}
