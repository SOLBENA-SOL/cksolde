import os
import re
import time
import logging
from flask import Flask, render_template, request, flash, redirect, url_for
import gspread
from oauth2client.service_account import ServiceAccountCredentials
import json

# Configure logging
logging.basicConfig(level=logging.DEBUG)

# Create Flask app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "dev-secret-key")

class GoogleSheetsService:
    def __init__(self):
        self.scope = ['https://spreadsheets.google.com/feeds', 'https://www.googleapis.com/auth/drive']
        self.sheet_key = '1s4dLGyLKffDQoAdG-T-rGUgKr_rV2wwNpjYqhIudr3Q'
        self.worksheet_name = 'SOLDE'
        
    def get_credentials(self):
        """Get Google Sheets credentials from JSON file"""
        try:
            # Use the credentials file directly like in the original Kivy code
            return ServiceAccountCredentials.from_json_keyfile_name('soldemembre-4fb12aff205e.json', self.scope)
        except Exception as e:
            logging.error(f"Error getting credentials: {e}")
            raise
    
    def get_balance(self, nom, compte):
        """Get balance from Google Sheets"""
        try:
            # Authenticate and open sheet
            creds = self.get_credentials()
            client = gspread.authorize(creds)
            sheet = client.open_by_key(self.sheet_key).worksheet(self.worksheet_name)
            
            logging.debug(f"Updating sheet with nom: {nom}, compte: {compte}")
            
            # Update name and account in sheet (same as original Kivy code)
            sheet.update('A2', [[nom]])
            sheet.update('B2', [[compte]])
            
            logging.debug("Data updated in sheet, waiting for calculation...")
            
            # Wait for calculation and retrieve balance (improved logic)
            solde = None
            for i in range(5):
                time.sleep(1.5)
                logging.debug(f"Attempt {i+1} to get balance from C2")
                
                try:
                    data = sheet.get('C2')
                    logging.debug(f"Raw data from C2: {data}")
                    
                    if data and len(data) > 0 and len(data[0]) > 0:
                        solde = data[0][0]
                        logging.debug(f"Found balance: {solde}")
                        if solde and str(solde).strip():  # Make sure it's not empty
                            break
                except Exception as e:
                    logging.error(f"Error reading C2 on attempt {i+1}: {e}")
                    continue
            
            logging.debug(f"Final balance result: {solde}")
            return solde
            
        except Exception as e:
            logging.error(f"Error getting balance: {e}")
            raise

# Initialize Google Sheets service
sheets_service = GoogleSheetsService()

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        nom = request.form.get('nom', '').strip()
        compte = request.form.get('compte', '').strip()
        
        # Validate inputs
        if not nom:
            flash('❌ Veuillez saisir le nom du membre', 'error')
            return render_template('index.html')
        
        if not compte:
            flash('❌ Veuillez saisir le numéro de compte', 'error')
            return render_template('index.html')
        
        # Validate account number format
        pattern = r'^[A-Za-z]{1}\d{6}-\d{2}$'
        if not re.match(pattern, compte):
            flash('❌ Format du compte invalide (ex: A123456-78)', 'error')
            return render_template('index.html')
        
        try:
            # Get balance from Google Sheets
            solde = sheets_service.get_balance(nom, compte)
            
            if solde:
                flash(f'✅ Solde du membre {nom} : {solde}', 'success')
            else:
                flash('⚠️ Solde non disponible ou formule vide', 'warning')
                
        except Exception as e:
            logging.error(f"Error processing request: {e}")
            flash(f'❌ Erreur lors de la récupération du solde: {str(e)}', 'error')
        
        return render_template('index.html')
    
    return render_template('index.html')

@app.errorhandler(404)
def not_found(error):
    return render_template('index.html'), 404

@app.errorhandler(500)
def internal_error(error):
    flash('❌ Erreur interne du serveur', 'error')
    return render_template('index.html'), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
