# APSOLDE - Balance Verification System

## Overview

APSOLDE is a web-based balance verification system that allows users to check account balances by integrating with Google Sheets. The application provides a simple interface where users can enter a member's name and account number to retrieve their balance information from a Google Sheets database.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: Flask with Jinja2 templating
- **UI Framework**: Bootstrap 5 for responsive design
- **Styling**: Custom CSS with gradient backgrounds and modern card-based layout
- **JavaScript**: Vanilla JavaScript for client-side validation and user experience enhancements
- **Icons**: Font Awesome for consistent iconography

### Backend Architecture
- **Web Framework**: Flask (Python)
- **Structure**: Simple monolithic architecture with a single Flask app
- **Service Layer**: `GoogleSheetsService` class handles all Google Sheets operations
- **Error Handling**: Comprehensive logging and flash message system for user feedback

### Data Storage Solutions
- **Primary Database**: Google Sheets used as the data source
- **Sheet Structure**: Uses a specific worksheet named 'SOLDE' with predefined cells for name (A2) and account (B2)
- **No Local Database**: All data operations are performed directly on Google Sheets

## Key Components

### 1. Google Sheets Integration
- **Service Class**: `GoogleSheetsService` manages all sheet operations
- **Authentication**: Uses OAuth2 service account credentials stored in environment variables
- **Data Flow**: Updates name and account in specific cells, then retrieves calculated balance

### 2. Web Interface
- **Single Page Application**: Main interface on index.html
- **Form Validation**: Both client-side and server-side validation
- **Account Format**: Enforces pattern A123456-78 (letter + 6 digits + dash + 2 digits)
- **Real-time Feedback**: JavaScript provides immediate validation feedback

### 3. Error Handling
- **Logging**: Comprehensive debug logging throughout the application
- **User Feedback**: Flash messages for success, error, and warning states
- **Input Validation**: Regex patterns for account number format validation

## Data Flow

1. **User Input**: User enters member name and account number
2. **Client Validation**: JavaScript validates account number format in real-time
3. **Form Submission**: Data sent to Flask backend via POST request
4. **Google Sheets Update**: Service updates cells A2 (name) and B2 (account)
5. **Balance Retrieval**: Service waits for calculation and retrieves balance
6. **Response**: Result displayed to user with appropriate feedback

## External Dependencies

### Required Python Packages
- `flask`: Web framework
- `gspread`: Google Sheets API client
- `oauth2client`: Google OAuth2 authentication

### External Services
- **Google Sheets API**: Primary data source and calculation engine
- **Google Drive API**: Required for sheet access permissions

### Frontend Dependencies
- **Bootstrap 5**: UI framework (CDN)
- **Font Awesome 6**: Icon library (CDN)

## Deployment Strategy

### Environment Configuration
- **SESSION_SECRET**: Flask session secret key (defaults to dev key)
- **GOOGLE_SHEETS_CREDENTIALS**: JSON credentials for Google Sheets API access

### Hosting Requirements
- **Python Runtime**: Flask application requires Python environment
- **Port Configuration**: Runs on port 5000 by default
- **HTTPS**: Recommended for production due to authentication requirements

### Security Considerations
- Service account credentials stored as environment variables
- No sensitive data stored locally
- Session management for flash messages

### Development vs Production
- **Development**: Debug mode enabled, uses dev secret key
- **Production**: Should use proper environment variables and disable debug mode

## Additional Notes

### Legacy Kivy Application
The repository contains remnants of a Kivy desktop application in the attached assets, suggesting this was originally a desktop application that was migrated to a web-based solution.

### Account Number Format
The system enforces a specific account number format (A123456-78) with both client-side and server-side validation to ensure data consistency with the Google Sheets calculations.

### Real-time Features
The application includes JavaScript enhancements for immediate user feedback during form input, improving user experience without requiring server round-trips for validation.